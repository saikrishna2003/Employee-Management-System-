package com.employeemanagement.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

//import com.busmanagement.entity.BusInfo;
import com.employeemanagement.entity.EmployeeInfo;
import com.employeemanagement.repository.EmployeeRepository;
import com.employeemanagement.service.EmployeeService;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

@RestController
@RequestMapping("/api/v1/")
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController {
	
	@Autowired
	EmployeeService empService;
	@Operation(summary = "Create a new employeeinfo")
	@ApiResponses(value = {@ApiResponse(responseCode = "201",description = "empinfo created successfully"),
			               @ApiResponse(responseCode = "400",description = "empinfo is invalid")
	                      })
	@ResponseStatus(HttpStatus.CREATED)
	@PostMapping(value="/employees")
	public ResponseEntity<EmployeeInfo> create(final @RequestBody EmployeeInfo empinfo){
		EmployeeInfo createempI = empService.create(empinfo);
		return ResponseEntity.ok(createempI);
	}
	
	//*************get by id
		@Operation(summary = "Get an employeeinfo with given id")
		@ApiResponses(value = {@ApiResponse(responseCode = "200",description = "Getting businfo successfully"),
				               @ApiResponse(responseCode = "401",description = "Invalid credentials"),
				               @ApiResponse(responseCode = "404",description = "empinfo not found")
		                      })
	
		
		
		@GetMapping(value = "employees/{id}",produces = "application/json")
		public ResponseEntity<Optional<EmployeeInfo>> read(final @PathVariable Long id){
			Optional<EmployeeInfo> createdemp = empService.read(id);
			return ResponseEntity.ok(createdemp);
		}
		
		//************get all
		@Operation(summary = "Get all EmpInfo")
	    @ApiResponses(value = {@ApiResponse(responseCode = "200" , description = "Getting All BusInfo successfully"),
	                 @ApiResponse(responseCode = "404" , description = "BusInfo not found")
	    })
	    
	   
		
		
		@GetMapping("employees")
	    public ResponseEntity<List<EmployeeInfo>> read (){
	      List<EmployeeInfo> createdemp   = empService.read();
	      return ResponseEntity.ok(createdemp);
	    }
		
 
//		
		//**************delete by id
		@Operation(summary = "Delete the empinfo by given id")
		@ApiResponses(value = {@ApiResponse(responseCode = "201",description = "Businfo deleted successfully"),
				               @ApiResponse(responseCode = "401",description = "Invalid credentials"),
				               @ApiResponse(responseCode = "404",description = "Businfo not found")
		                      })
		@ResponseStatus(HttpStatus.OK)
		@DeleteMapping("employees/{id}")
		public void delete(final @PathVariable("id") Long id){
			empService.delete(id);
			
		}
		
		
		@Operation(summary = "Updates Bus Details for given id")
	    @ApiResponses(value = {
	        @ApiResponse(responseCode = "201", description = "Record was updated successfully!"),
	        @ApiResponse(responseCode = "400", description = "Could not update bus record")
	    })
	    @ResponseStatus(HttpStatus.OK)
	    @PutMapping(value = "employees/{id}", produces = "application/json")
	    public void updateEmp(final @RequestBody EmployeeInfo new_record, @PathVariable("id") Long id) {
	      
	      empService.updateEmp(new_record, id);
	    }
 
}
