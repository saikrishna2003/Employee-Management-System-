package com.employeemanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeemanagement.entity.SignUp;
import com.employeemanagement.repository.SignUpRepo;
@Service
public class SignUpService {
  @Autowired 
  SignUpRepo repo;
//  public Iterable<SignUp> GetUserPassService(String username){
//    return repo.findAllUsernamePassword(username);
//  }
  public Iterable<SignUp> GetAll(){
    return repo.findAll();
  }
  
}