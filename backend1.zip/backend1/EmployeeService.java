package com.employeemanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeemanagement.entity.EmployeeInfo;
import com.employeemanagement.repository.EmployeeRepository;
@Service
public class EmployeeService {

	@Autowired
	EmployeeRepository empRepository;
	
	public EmployeeInfo create(EmployeeInfo openI) {
		return empRepository.save(openI);
	}
	public Optional<EmployeeInfo>read(Long id){
		return empRepository.findById(id);
	}
	public EmployeeInfo update(EmployeeInfo openI){
		return empRepository.save(openI);
	}
	
//	EmployeeInfo update = empRepository.findById().get();
//    
//    if(update == null)
//    {
//      return update;
//    }
//    else
//    {
//      update.setName(EmployeeInfo.getName());
//      update.setDepartment(EmployeeInfo.getDepartment());
//      update.setRole(EmployeeInfo.getRole());
//      update.setSalary(EmployeeInfo.getSalary());
//      update.setAddress(EmployeeInfo.getAddress());
//      
//    }
//    
//    return empRepository.save(update);
//  }
//	
	
	public EmployeeInfo updateEmp(EmployeeInfo new_record, Long id) {
	      
	      EmployeeInfo updateEmp = empRepository.findById(id).get();
	      
	      if(updateEmp == null)
	      {
	        return updateEmp;
	      }
	      else
	      {
	        updateEmp.setName(new_record.getName());
	        updateEmp.setDepartment(new_record.getDepartment());
	        updateEmp.setRole(new_record.getRole());
	        updateEmp.setRole(new_record.getRole());
	        updateEmp.setSalary(new_record.getSalary());
	        updateEmp.setAddress(new_record.getAddress());
	        
	      }
	      
	      return empRepository.save(updateEmp);
	    }
	public String delete(Long id) {
		empRepository.deleteById(id);
		return id +" is deleted";
	}
	public List<EmployeeInfo> read(){
	    return empRepository.findAll();
	}
}
