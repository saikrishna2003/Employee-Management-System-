import React from 'react'
import { Link } from 'react-router-dom'
import "./SignUp.css"

function SignUp() {
  return (
    <div class="wrapper fadeInDown">
  <div id="formContent">
    
    <h2 class="active"> Sign Up </h2>
    {/* <h2 class="active"> Sign In </h2> */}

  
    <div class="fadeIn first">
      
    </div>

    
    <form>
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="First Name"/>
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="Last Name"/>
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="Email"/>
      <input type="password" id="password" class="fadeIn second" name="login" placeholder="Password"/>
      <input type="submit" class="fadeIn fourth" value="Sign Up"/>
    </form>

    <Link to='/signin'>Already have account?</Link>

  </div>
</div>
  
  )
}

export default SignUp