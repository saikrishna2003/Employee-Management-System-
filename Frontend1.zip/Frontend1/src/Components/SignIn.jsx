import React from 'react'
import ReactDOM from "react-dom/client";
import "./SignIn.css" 
function SignIn() {
  return (
<div class="wrapper fadeInDown">
  <div id="formContent">
    
    <h2 class="active"> Sign In </h2>
    
  
    <div class="fadeIn first">
      
    </div>

    
    <form>
      <input type="text" id="login" class="fadeIn second" name="login" placeholder="login"/>
      <input type="text" id="password" class="fadeIn third" name="login" placeholder="password"/>
      <input type="submit" class="fadeIn fourth" value="Log In"/>
    </form>

    

  </div>
</div>
  )
}

export default SignIn